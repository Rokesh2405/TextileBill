<?php
if (isset($_REQUEST['bid'])) {
    $thispageeditid = 10;
} else {
    $thispageaddid = 10;
}
$menu = "8,8,13";
include ('../../config/config.inc.php');
$dynamic = '1';
include ('../../require/header.php');

if (isset($_REQUEST['submit'])) {
    @extract($_REQUEST);
    $getid = $_REQUEST['bid'];
    $ip = $_SERVER['REMOTE_ADDR'];

$msg = addbankstatus($receiptno,$bankname,$dateofpawn,$object,$weight,$amount,$interestpercent, $interest, $status, $totalamount, $date,$ip, $getid);
}

// if (isset($_REQUEST['cid']) && ($_REQUEST['cid'] != '')) {
//     $get1 = $db->prepare("SELECT * FROM `bankstatus` WHERE `id`=?");
//     $get1->execute(array($_REQUEST['id']));
//     $showrecords = $get1->fetch(PDO::FETCH_ASSOC);
// }
?>

<script>
    function randomString()
    {
        var chars = "0123456789ABCDEFGHIJKLMNOPQRSTUVWXTZabcdefghiklmnopqrstuvwxyz";
        var string_length = 6;
        var randomstring = '';
        for (var i = 0; i < string_length; i++) {
            var rnum = Math.floor(Math.random() * chars.length);
            randomstring += chars.substring(rnum, rnum + 1);
        }
        document.getElementById('password').value = randomstring;
        document.getElementById('changepwd').value = randomstring;
    }
    
    $(function () {
        $(".form_control").blur(function () {
            var PasswordVal = $('.password').val();
            var ConfirmPasswordVal = $('.confirmpassword').val();
            if (PasswordVal != ConfirmPasswordVal && ConfirmPasswordVal.length > 0 && PasswordVal.length > 0)
                $('reg-textbox').show();
            else
                $('reg-textbox').hide();

        });
    });

 </script>   
    
    
<!-- Content Wrapper. Contains page content -->
<div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
        <h1>
            Bank Status
            <small><?php
                if ($_REQUEST['bid'] != '') {
                    echo 'Edit';
                } else {
                    echo 'Add New';
                }
                ?> Bank Status</small>
        </h1>
        <ol class="breadcrumb">
            <li><a href="<?php echo $sitename; ?>"><i class="fa fa-dashboard"></i> Dashboard</a></li>
            <li><a href="#"><i class="fa fa-asterisk"></i> Master(s)</a></li>            
            <li><a href="<?php echo $sitename; ?>master/bankstatus.htm"><i class="fa fa-circle-o"></i> Bank Status</a></li>
            <li class="active"><?php
                if ($_REQUEST['bid'] != '') {
                    echo 'Edit';
                } else {
                    echo 'Add New';
                }
                ?> Bank Status</li>
        </ol>
    </section>

    <!-- Main content -->
    <section class="content">
        <form name="department" id="department"  method="post" enctype="multipart/form-data">
            <div class="box box-info">
                <div class="box-header with-border">
                    <h3 class="box-title"><?php
                        if ($_REQUEST['bid'] != '') {
                            echo 'Edit';
                        } else {
                            echo 'Add New';
                        }
                        ?> Bank Status</h3>
                    <span style="float:right; font-size:13px; color: #333333; text-align: right;"><span style="color:#FF0000;">*</span> Marked Fields are Mandatory</span>
                </div>
                <div class="box-body">
                    <?php echo $msg; ?>
                    <div class="row">
                        
                        <div class="col-md-4">
                             <label>Receipt Number<span style="color:#FF0000;">*</span></label>
                         <?php //$purid = get_bill_settings('prefix', '2') . str_pad(get_bill_settings('current_value', '2'), get_bill_settings('format', '1'), '0', STR_PAD_LEFT);
                                    ?>
                                    <input type="text" name="receiptno" id="receiptno" class="form-control" placeholder="Enter the Receipt Number" value="<?php echo (getbankstatus('receiptno',$_REQUEST['bid'])); ?>" />
                        </div> 
                        <div class="col-md-4">
                            <label>Date of Pawn<span style="color:#FF0000;">*</span></label>
                             <div class="input-group date">
                                        <div class="input-group-addon">
                                            <i class="fa fa-calendar"></i>
                                        </div>
                                        <input type="text" class="form-control pull-right usedatepicker" name="dateofpawn" id="dateofpawn" required="required"  value="<?php
                                        if (isset($_REQUEST['bid']) && (date('d-m-Y', strtotime(getbankstatus('dateofpawn',$_REQUEST['bid']))) != '01-01-1970')) {
                                            echo date('d-m-Y', strtotime(getbankstatus('dateofpawn',$_REQUEST['bid'])));
                                        } else {
                                            echo date('d-m-Y');
                                        }
                                        ?>" >
                                    </div>  
                        </div>
                         <div class="col-md-4">
                             <label>Bank Name <span style="color:#FF0000;">*</span></label>
                         <?php //$purid = get_bill_settings('prefix', '2') . str_pad(get_bill_settings('current_value', '2'), get_bill_settings('format', '1'), '0', STR_PAD_LEFT);
                                    ?>
                                    <input type="text" name="bankname" id="bankname" placeholder="Enter the Bank Name"  class="form-control" value="<?php echo (getbankstatus('bankname',$_REQUEST['bid'])); ?>" />
                        </div> 
                    </div>
                    
                     <div class="clearfix"><br /></div>
                    <div class="row">
                         
                        <div class="col-md-4">
                         <button type="submit" name="objectsubmit" id="objectsubmit" class="btn btn-success" style="float:left;">Object</button></div>
                         <div class="col-md-8">
                             <textarea name="object" class="form-control"></textarea>
                            </div>
                        
                    </div>  
                     <div class="clearfix"><br /></div>
                    <div class="row">
                          <div class="col-md-4">
                            <label>Weight <span style="color:#FF0000;">*</span></label>
                            <input type="text"  required="required" name="weight" id="weight" placeholder="Enter Weight" class="form-control" value="<?php echo stripslashes(getbankstatus('weight',$_REQUEST['bid'])); ?>" maxlength="10"/>
                        </div>
                        <div class="col-md-4">
                            <label>Amount <span style="color:#FF0000;">*</span></label>
                            <input type="text" required="required" name="amount" id="amount" placeholder="Enter Amount" class="form-control" value="<?php echo stripslashes(getbankstatus('amount',$_REQUEST['bid'])); ?>" maxlength="10"/>
                        </div>
                         <div class="col-md-4">
                            <label>Interest Percent<span style="color:#FF0000;">*</span></label>
                            <input type="text" id="interestpercent"  name="interestpercent" placeholder="Enter Interest Percent" class="form-control" value="<?php echo stripslashes(getbankstatus('interestpercent',$_REQUEST['bid'])); ?>" />
                        </div>
                       
                    </div> 
                     
                     <br>
                     <div class="row">
                          <div class="col-md-4">
                            <label>Interest <span style="color:#FF0000;">*</span></label>
                            <input type="text" required="required" id="interest"  name="interest" placeholder="Enter Interest Amount" class="form-control" value="<?php echo stripslashes(getbankstatus('interest', $_REQUEST['bid'])); ?>" />
                        </div>
                         <div class="col-md-4">
                            <label>Status <span style="color:#FF0000;">*</span></label>
                            <input type="text" required="required" id="status"  name="status" placeholder="Enter the Status" class="form-control" value="<?php echo stripslashes(getbankstatus('status',$_REQUEST['bid'])); ?>" />
                        </div>
                         <div class="col-md-4">
                            <label>Total Amount <span style="color:#FF0000;">*</span></label>
                            <input type="text" required="required" id="totalamount"  name="totalamount" placeholder="Enter Total Amount" class="form-control" value="<?php echo stripslashes(getbankstatus('totalamount',$_REQUEST['bid'])); ?>" />
                            <!-- pattern="[a-z0-9._%+-]+@[a-z0-9.-]+\.[a-z]{2,3}$" -->
                        </div>
                     </div>    
                     <br>
                     <div class="row">
                          <div class="col-md-4">
                            <label>Date<span style="color:#FF0000;">*</span></label>
                             <div class="input-group date">
                                        <div class="input-group-addon">
                                            <i class="fa fa-calendar"></i>
                                        </div>
                                        <input type="text" class="form-control pull-right usedatepicker" name="date" id="date" required="required"  value="<?php
                                        if (isset($_REQUEST['bid']) && (date('d-m-Y', strtotime(getbankstatus('date',$_REQUEST['bid']))) != '01-01-1970')) {
                                            echo date('d-m-Y', strtotime(getbankstatus('date',$_REQUEST['bid'])));
                                        } else {
                                            echo date('d-m-Y');
                                        }
                                        ?>" >
                                    </div>
                          </div>  </div><br>
                </div<!-- /.box-body -->
                <div class="box-footer">
                    <div class="row">
                        <div class="col-md-6">
                            <a href="<?php echo $sitename; ?>master/bankstatus.htm">Back to Listings page</a>
                        </div>
                        <div class="col-md-6">
                            <button type="submit" name="submit" id="submit" class="btn btn-success" style="float:right;"><?php
                                if ($_REQUEST['bid'] != '') {
                                    echo 'UPDATE';
                                } else {
                                    echo 'SUBMIT';
                                }
                                ?></button>
                        </div>
                    </div>
                </div>
            </div><!-- /.box -->
        </form>
    </section><!-- /.content -->
</div><!-- /.content-wrapper -->
<?php include ('../../require/footer.php'); ?>
<script type="text/javascript">

     function show_contacts(id) {
        $.ajax({
            url: "<?php echo $sitename; ?>getpassup.php",
            data: {get_contacts_of_customer: id}
        }).done(function (data) {
            $('#choose_contacts_grid_table tbody').html(data);
        });
    }


      function delrec(elem, id) {
        if (confirm("Are you sure want to delete this Object?")) {
            $(elem).parent().remove();
            window.location.href = "<?php echo $sitename; ?>master/<?php echo getbankstatus('id',$_REQUEST['bid']); ?>/editprovider.htm?delid=" + id;
        }
    }


    $(document).ready(function (e) {
        
        $('#add_task').click(function () {

           
            var data = $('#firsttasktr').clone();
            var rem_td = $('<td />').html('<i class="fa fa-trash fa-2x" style="color:#F00;cursor:pointer;"></i>').click(function () {
                if (confirm("Do you want to delete the Offer?")) {
                    $(this).parent().remove();
                    re_assing_serial();
                   
                }
            });
            $(data).attr('id', '').show().append(rem_td);

            data = $(data);
            $('#task_table tbody').append(data);
             $('.usedatepicker').datepicker({
                autoclose: true
            });

           
            re_assing_serial();

        });

      });

    function del_addi(elem) {
        if (confirm("Are you sure want to remove this?")) {
            elem.parent().parent().remove();
            additionalprice();
        }
    }


   
   
    
    function re_assing_serial() {
        $("#task_table tbody tr").not('#firsttasktr').each(function (i, e) {
            $(this).find('td').eq(0).html(i + 1+1);
        });
        $("#worker_table tbody tr").not('#firstworkertr').each(function (i, e) {
            $(this).find('td').eq(0).html(i + 1);
        });
    }

</script>