<?php
if (isset($_REQUEST['cid'])) {
    $thispageeditid = 10;
} else {
    $thispageaddid = 10;
}
$menu = "8,8,10";
include ('../../config/config.inc.php');
$dynamic = '1';
include ('../../require/header.php');

if (isset($_REQUEST['submit'])) {
    @extract($_REQUEST);
    $getid = $_REQUEST['cid'];
    $ip = $_SERVER['REMOTE_ADDR'];

$msg = addcustomer($username,$password,$servicetype,$rank,$customerid,$membership,$title, $cname, $area, $mobile, $emailid, $joineddate, $valid_fromdate, $valid_todate, $address, $description, $payment, $status,$ip, $getid);
}

if (isset($_REQUEST['cid']) && ($_REQUEST['cid'] != '')) {
    $get1 = $db->prepare("SELECT * FROM `return` WHERE `id`=?");
    $get1->execute(array($_REQUEST['id']));
    $showrecords = $get1->fetch(PDO::FETCH_ASSOC);
}
?>

<script>
    function randomString()
    {
        var chars = "0123456789ABCDEFGHIJKLMNOPQRSTUVWXTZabcdefghiklmnopqrstuvwxyz";
        var string_length = 6;
        var randomstring = '';
        for (var i = 0; i < string_length; i++) {
            var rnum = Math.floor(Math.random() * chars.length);
            randomstring += chars.substring(rnum, rnum + 1);
        }
        document.getElementById('password').value = randomstring;
        document.getElementById('changepwd').value = randomstring;
    }
    
    $(function () {
        $(".form_control").blur(function () {
            var PasswordVal = $('.password').val();
            var ConfirmPasswordVal = $('.confirmpassword').val();
            if (PasswordVal != ConfirmPasswordVal && ConfirmPasswordVal.length > 0 && PasswordVal.length > 0)
                $('reg-textbox').show();
            else
                $('reg-textbox').hide();

        });
    });

 </script>   
    
    
<!-- Content Wrapper. Contains page content -->
<div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
        <h1>
            Bank Pawn
            <small><?php
                if ($_REQUEST['cid'] != '') {
                    echo 'Edit';
                } else {
                    echo 'Add New';
                }
                ?> Bank Pawn</small>
        </h1>
        <ol class="breadcrumb">
            <li><a href="<?php echo $sitename; ?>"><i class="fa fa-dashboard"></i> Dashboard</a></li>
            <li><a href="#"><i class="fa fa-asterisk"></i> Master(s)</a></li>            
            <li><a href="<?php echo $sitename; ?>master/bankpawn.htm"><i class="fa fa-circle-o"></i> Bank Pawn</a></li>
            <li class="active"><?php
                if ($_REQUEST['cid'] != '') {
                    echo 'Edit';
                } else {
                    echo 'Add New';
                }
                ?> Bank Pawn</li>
        </ol>
    </section>

    <!-- Main content -->
    <section class="content">
        <form name="department" id="department"  method="post" enctype="multipart/form-data">
            <div class="box box-info">
                <div class="box-header with-border">
                    <h3 class="box-title"><?php
                        if ($_REQUEST['cid'] != '') {
                            echo 'Edit';
                        } else {
                            echo 'Add New';
                        }
                        ?> Bank Pawn</h3>
                    <span style="float:right; font-size:13px; color: #333333; text-align: right;"><span style="color:#FF0000;">*</span> Marked Fields are Mandatory</span>
                </div>
                <div class="box-body">
                    <?php echo $msg; ?>
                    
                   
                    <div class="row">
                       
                        <div class="col-md-4">
                            <label>Year <span style="color:#FF0000;">*</span></label>
                            <input type="text" required="required" name="mobile" id="mobile" placeholder="Enter Year" class="form-control" value="<?php echo (isset($_REQUEST['cid'])) ? stripslashes($showrecords['mobile']) : '' ?>" maxlength="10"/>
                        </div>
                        <div class="col-md-4"  align="center"><br>
                           <button type="submit" name="submit" id="submit" class="btn btn-success" style="float:center;">Year Wise View</button></div>
                        <div class="col-md-4">
                            <label>Status <span style="color:#FF0000;">*</span></label>
                            <select name="status" id="status" class="form-control">
                                <option value="Returned">Returned</option>    
                            </select>    
                        </div>
                    </div> 
                     <br>
                    <div class="row">
                         
                        <div class="col-md-4">
                            <label>Month <span style="color:#FF0000;">*</span></label>
                            <input type="text" required="required" name="mobile" id="mobile" placeholder="Enter Month" class="form-control" value="<?php echo (isset($_REQUEST['cid'])) ? stripslashes($showrecords['mobile']) : '' ?>" maxlength="10"/>
                        </div>
                        <div class="col-md-4"  align="center"><br>
                           <button type="submit" name="submit" id="submit" class="btn btn-success" style="float:center;">Month Wise View</button></div>
                        <div class="col-md-4">
                            <label>Page Size <span style="color:#FF0000;">*</span></label>
                            <input type="text" required="required" name="mobile" id="mobile" placeholder="Enter Page Size" class="form-control" value="<?php echo (isset($_REQUEST['cid'])) ? stripslashes($showrecords['mobile']) : '' ?>" maxlength="10"/>
                       
                        </div>
                    </div> 
                       <br>
                    <div class="row">
                       
                       <div class="col-md-4">
                            <label>Date<span style="color:#FF0000;">*</span></label>
                             <div class="input-group date">
                                        <div class="input-group-addon">
                                            <i class="fa fa-calendar"></i>
                                        </div>
                                        <input type="text" class="form-control pull-right usedatepicker" name="joineddate" id="joineddate" required="required"  value="<?php
                                        if (isset($_REQUEST['cid']) && (date('d-m-Y', strtotime($showrecords['joineddate'])) != '01-01-1970')) {
                                            echo date('d-m-Y', strtotime($showrecords['joineddate']));
                                        } else {
                                            echo date('d-m-Y');
                                        }
                                        ?>" >
                                    </div>  
                        </div><div class="col-md-4" align="center">
                            <br>
                         <button type="submit" name="submit" id="submit" class="btn btn-success" style="float:center;">Date Wise View</button>
                        </div>
                    </div> 
                     <br>
                </div<!-- /.box-body -->
                <div class="box-footer">
                    <div class="row">
                        <div class="col-md-6">
                            <a href="<?php echo $sitename; ?>master/bankpawn.htm">Back to Listings page</a>
                        </div>
                        <div class="col-md-6">
                            <button type="submit" name="submit" id="submit" class="btn btn-success" style="float:right;"><?php
                                if ($_REQUEST['cid'] != '') {
                                    echo 'UPDATE';
                                } else {
                                    echo 'Click here to Calculate Total Amount';
                                }
                                ?></button>
                        </div>
                    </div>
                </div>
            </div><!-- /.box -->
        </form>
    </section><!-- /.content -->
</div><!-- /.content-wrapper -->
<?php include ('../../require/footer.php'); ?>
<script type="text/javascript">

     function show_contacts(id) {
        $.ajax({
            url: "<?php echo $sitename; ?>getpassup.php",
            data: {get_contacts_of_customer: id}
        }).done(function (data) {
            $('#choose_contacts_grid_table tbody').html(data);
        });
    }


      function delrec(elem, id) {
        if (confirm("Are you sure want to delete this Object?")) {
            $(elem).parent().remove();
            window.location.href = "<?php echo $sitename; ?>master/<?php echo $showrecords['id'] ?>/editprovider.htm?delid=" + id;
        }
    }


    $(document).ready(function (e) {
        
        $('#add_task').click(function () {

           
            var data = $('#firsttasktr').clone();
            var rem_td = $('<td />').html('<i class="fa fa-trash fa-2x" style="color:#F00;cursor:pointer;"></i>').click(function () {
                if (confirm("Do you want to delete the Offer?")) {
                    $(this).parent().remove();
                    re_assing_serial();
                   
                }
            });
            $(data).attr('id', '').show().append(rem_td);

            data = $(data);
            $('#task_table tbody').append(data);
             $('.usedatepicker').datepicker({
                autoclose: true
            });

           
            re_assing_serial();

        });

      });

    function del_addi(elem) {
        if (confirm("Are you sure want to remove this?")) {
            elem.parent().parent().remove();
            additionalprice();
        }
    }


   
   
    
    function re_assing_serial() {
        $("#task_table tbody tr").not('#firsttasktr').each(function (i, e) {
            $(this).find('td').eq(0).html(i + 1+1);
        });
        $("#worker_table tbody tr").not('#firstworkertr').each(function (i, e) {
            $(this).find('td').eq(0).html(i + 1);
        });
    }

</script>