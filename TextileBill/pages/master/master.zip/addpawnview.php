<?php
if (isset($_REQUEST['pid'])) {
    $thispageeditid = 10;
} else {
    $thispageaddid = 10;
}
$menu = "8,8,14";
include ('../../config/config.inc.php');
$dynamic = '1';
include ('../../require/header.php');

if (isset($_REQUEST['submit'])) {
    @extract($_REQUEST);
    $getid = $_REQUEST['pid'];
    $ip = $_SERVER['REMOTE_ADDR'];

$msg = addpawnview($noofpawn,$noofreturn,$noofcancel,$totalbill,$receiptno,$membership,$title, $cname, $area, $mobile, $emailid, $joineddate, $valid_fromdate, $valid_todate, $address, $description, $payment, $status,$ip, $getid);
}

if (isset($_REQUEST['pid']) && ($_REQUEST['pid'] != '')) {
    $get1 = $db->prepare("SELECT * FROM `return` WHERE `id`=?");
    $get1->execute(array($_REQUEST['id']));
    $showrecords = $get1->fetch(PDO::FETCH_ASSOC);
}
?>

<script>
    function randomString()
    {
        var chars = "0123456789ABCDEFGHIJKLMNOPQRSTUVWXTZabcdefghiklmnopqrstuvwxyz";
        var string_length = 6;
        var randomstring = '';
        for (var i = 0; i < string_length; i++) {
            var rnum = Math.floor(Math.random() * chars.length);
            randomstring += chars.substring(rnum, rnum + 1);
        }
        document.getElementById('password').value = randomstring;
        document.getElementById('changepwd').value = randomstring;
    }
    
    $(function () {
        $(".form_control").blur(function () {
            var PasswordVal = $('.password').val();
            var ConfirmPasswordVal = $('.confirmpassword').val();
            if (PasswordVal != ConfirmPasswordVal && ConfirmPasswordVal.length > 0 && PasswordVal.length > 0)
                $('reg-textbox').show();
            else
                $('reg-textbox').hide();

        });
    });

 </script>   
    
    
<!-- Content Wrapper. Contains page content -->
<div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
        <h1>
            Pawn View
            <small><?php
                if ($_REQUEST['pid'] != '') {
                    echo 'Edit';
                } else {
                    echo 'Add New';
                }
                ?> Pawn View</small>
        </h1>
        <ol class="breadcrumb">
            <li><a href="<?php echo $sitename; ?>"><i class="fa fa-dashboard"></i> Dashboard</a></li>
            <li><a href="#"><i class="fa fa-asterisk"></i> Master(s)</a></li>            
            <li><a href="<?php echo $sitename; ?>master/pawnview.htm"><i class="fa fa-circle-o"></i> Pawn View</a></li>
            <li class="active"><?php
                if ($_REQUEST['pid'] != '') {
                    echo 'Edit';
                } else {
                    echo 'Add New';
                }
                ?> Pawn View</li>
        </ol>
    </section>

    <!-- Main content -->
    <section class="content">
        <form name="department" id="department"  method="post" enctype="multipart/form-data">
            <div class="box box-info">
                <div class="box-header with-border">
                    <h3 class="box-title"><?php
                        if ($_REQUEST['pid'] != '') {
                            echo 'Edit';
                        } else {
                            echo 'Add New';
                        }
                        ?> Pawn View</h3>
                    <span style="float:right; font-size:13px; color: #333333; text-align: right;"><span style="color:#FF0000;">*</span> Marked Fields are Mandatory</span>
                </div>
                <div class="box-body">
                    <?php echo $msg; ?>
                    <div class="row">
                        
                        <div class="col-md-3">
                             <label>No of Pawn<span style="color:#FF0000;">*</span></label>
                         <?php //$purid = get_bill_settings('prefix', '2') . str_pad(get_bill_settings('current_value', '2'), get_bill_settings('format', '1'), '0', STR_PAD_LEFT);
                                    ?>
                                    <input type="text" name="noofpawn" id="noofpawn" class="form-control" placeholder="No of Pawn" value="<?php echo (getpawnview('noofpawn',$_REQUEST['pid'])); ?>" />
                        </div> 
                         <div class="col-md-3">
                             <label>No of Return <span style="color:#FF0000;">*</span></label>
                         <?php //$purid = get_bill_settings('prefix', '2') . str_pad(get_bill_settings('current_value', '2'), get_bill_settings('format', '1'), '0', STR_PAD_LEFT);
                                    ?>
                                    <input type="text" name="noofreturn" id="noofreturn" placeholder="No of Return"  class="form-control" value="<?php echo (getpawnview('noofreturn',$_REQUEST['pid'])); ?>" />
                        </div> 
                        <div class="col-md-3">
                             <label>No of Cancel <span style="color:#FF0000;">*</span></label>
                         <?php //$purid = get_bill_settings('prefix', '2') . str_pad(get_bill_settings('current_value', '2'), get_bill_settings('format', '1'), '0', STR_PAD_LEFT);
                                    ?>
                                    <input type="text" name="noofcancel" id="noofcancel" placeholder="No of Cancel"  class="form-control" value="<?php echo (getpawnview('noofcancel',$_REQUEST['pid'])); ?>" />
                        </div> 
                        <div class="col-md-3">
                             <label>Total Bill Performed <span style="color:#FF0000;">*</span></label>
                         <?php //$purid = get_bill_settings('prefix', '2') . str_pad(get_bill_settings('current_value', '2'), get_bill_settings('format', '1'), '0', STR_PAD_LEFT);
                                    ?>
                                    <input type="text" name="totalbill" id="totalbill" placeholder="Total Bill Performed"  class="form-control" value="<?php echo (getpawnview('totalbill',$_REQUEST['pid'])); ?>" />
                        </div> 
                    </div>
                    
                     <div class="clearfix"><br /></div>
                   
                    <div class="row">
                          <div class="col-md-3">
                            <label>Receipt Number <span style="color:#FF0000;">*</span></label>
                            <input type="text"  required="required" name="receiptno" id="receiptno" placeholder="Enter Receipt Number" class="form-control" value="<?php echo stripslashes(getpawnview('receiptno',$_REQUEST['pid'])); ?>" maxlength="10"/>
                        </div>
                        <div class="col-md-3">
                            <label>Year <span style="color:#FF0000;">*</span></label>
                            <input type="text" required="required" name="year" id="year" placeholder="Enter Year" class="form-control" value="<?php echo stripslashes(getpawnview('year',$_REQUEST['pid'])); ?>" maxlength="10"/>
                        </div>
                        <div class="col-md-3"><br>
                           <button type="submit" name="submit" id="submit" class="btn btn-success" style="float:left;">Year Wise View</button></div>
                        <div class="col-md-3">
                            <label>Status <span style="color:#FF0000;">*</span></label>
                            <select name="status" id="status" class="form-control">
                                <option value="Pawned">Pawned</option>    
                            </select>    
                        </div>
                    </div> 
                     <br>
                    <div class="row">
                          <div class="col-md-3">
                            <label>Customer ID<span style="color:#FF0000;">*</span></label>
                            <input type="text"  required="required" name="customerid" id="customerid" placeholder="Enter Customer ID" class="form-control" value="<?php echo (isset($_REQUEST['pid'])) ? stripslashes($showrecords['mobile']) : '' ?>" maxlength="10"/>
                        </div>
                        <div class="col-md-3">
                            <label>Month <span style="color:#FF0000;">*</span></label>
                            <input type="text" required="required" name="month" id="month" placeholder="Enter Month" class="form-control" value="<?php echo stripslashes(getpawnview('mobile',$_REQUEST['pid'])); ?>" maxlength="10"/>
                        </div>
                        <div class="col-md-3"><br>
                           <button type="submit" name="submit" id="submit" class="btn btn-success" style="float:left;">Month Wise View</button></div>
                        <div class="col-md-3">
                            <label>Page Size <span style="color:#FF0000;">*</span></label>
                            <input type="text" required="required" name="pagesize" id="pagesize" placeholder="Enter Page Size" class="form-control" value="<?php echo stripslashes(getpawnview('mobile',$_REQUEST['pid'])); ?>" maxlength="10"/>
                       
                        </div>
                    </div> 
                       <br>
                    <div class="row">
                          <div class="col-md-3">
                            &nbsp;
                          </div>
                       
                        <div class="col-md-3">
                            <br>
                         <button type="submit" name="submit" id="submit" class="btn btn-success" style="float:left;">Find</button></div>
                       <div class="col-md-3">
                            <label>Date<span style="color:#FF0000;">*</span></label>
                             <div class="input-group date">
                                        <div class="input-group-addon">
                                            <i class="fa fa-calendar"></i>
                                        </div>
                                        <input type="text" class="form-control pull-right usedatepicker" name="date" id="date" required="required"  value="<?php
                                        if (isset($_REQUEST['pid']) && (date('d-m-Y', strtotime(getpawnview('date',$_REQUEST['pid']))) != '01-01-1970')) {
                                            echo date('d-m-Y', strtotime(getpawnview('date',$_REQUEST['pid'])));
                                        } else {
                                            echo date('d-m-Y');
                                        }
                                        ?>" >
                                    </div>  
                        </div><div class="col-md-3">
                            <br>
                         <button type="submit" name="submit" id="submit" class="btn btn-success" style="float:left;">Date Wise View</button>
                        </div>
                    </div> 
                     <br>
                </div<!-- /.box-body -->
                <div class="box-footer">
                    <div class="row">
                        <div class="col-md-6">
                            <a href="<?php echo $sitename; ?>master/pawnview.htm">Back to Listings page</a>
                        </div>
                        <div class="col-md-6">
                            <button type="submit" name="submit" id="submit" class="btn btn-success" style="float:right;"><?php
                                if ($_REQUEST['pid'] != '') {
                                    echo 'UPDATE';
                                } else {
                                    echo 'Click here to Calculate Total Amount';
                                }
                                ?></button>
                        </div>
                    </div>
                </div>
            </div><!-- /.box -->
        </form>
    </section><!-- /.content -->
</div><!-- /.content-wrapper -->
<?php include ('../../require/footer.php'); ?>
<script type="text/javascript">

     function show_contacts(id) {
        $.ajax({
            url: "<?php echo $sitename; ?>getpassup.php",
            data: {get_contacts_of_customer: id}
        }).done(function (data) {
            $('#choose_contacts_grid_table tbody').html(data);
        });
    }


      function delrec(elem, id) {
        if (confirm("Are you sure want to delete this Object?")) {
            $(elem).parent().remove();
            window.location.href = "<?php echo $sitename; ?>master/<?php echo $showrecords['id'] ?>/editprovider.htm?delid=" + id;
        }
    }


    $(document).ready(function (e) {
        
        $('#add_task').click(function () {

           
            var data = $('#firsttasktr').clone();
            var rem_td = $('<td />').html('<i class="fa fa-trash fa-2x" style="color:#F00;cursor:pointer;"></i>').click(function () {
                if (confirm("Do you want to delete the Offer?")) {
                    $(this).parent().remove();
                    re_assing_serial();
                   
                }
            });
            $(data).attr('id', '').show().append(rem_td);

            data = $(data);
            $('#task_table tbody').append(data);
             $('.usedatepicker').datepicker({
                autoclose: true
            });

           
            re_assing_serial();

        });

      });

    function del_addi(elem) {
        if (confirm("Are you sure want to remove this?")) {
            elem.parent().parent().remove();
            additionalprice();
        }
    }


   
   
    
    function re_assing_serial() {
        $("#task_table tbody tr").not('#firsttasktr').each(function (i, e) {
            $(this).find('td').eq(0).html(i + 1+1);
        });
        $("#worker_table tbody tr").not('#firstworkertr').each(function (i, e) {
            $(this).find('td').eq(0).html(i + 1);
        });
    }

</script>