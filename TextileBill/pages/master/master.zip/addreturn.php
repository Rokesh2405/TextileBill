<?php
if (isset($_REQUEST['cid'])) {
    $thispageeditid = 10;
} else {
    $thispageaddid = 10;
}
$menu = "8,12,12";
include ('../../config/config.inc.php');
$dynamic = '1';
include ('../../require/header.php');

if (isset($_REQUEST['submit'])) {
    @extract($_REQUEST);
    $getid = $_REQUEST['cid'];
    $ip = $_SERVER['REMOTE_ADDR'];

$msg = addreturn($customerid,$object,$receiptno,$date,$name,$mobileno,$netweight,$amount,$interestpercent,$status,$ip, $getid);
}

if (isset($_REQUEST['cid']) && ($_REQUEST['cid'] != '')) {
    $get1 = $db->prepare("SELECT * FROM `return` WHERE `id`=?");
    $get1->execute(array($_REQUEST['cid']));
    $showrecords = $get1->fetch(PDO::FETCH_ASSOC);
}
?>

<script>
    function randomString()
    {
        var chars = "0123456789ABCDEFGHIJKLMNOPQRSTUVWXTZabcdefghiklmnopqrstuvwxyz";
        var string_length = 6;
        var randomstring = '';
        for (var i = 0; i < string_length; i++) {
            var rnum = Math.floor(Math.random() * chars.length);
            randomstring += chars.substring(rnum, rnum + 1);
        }
        document.getElementById('password').value = randomstring;
        document.getElementById('changepwd').value = randomstring;
    }
    
    $(function () {
        $(".form_control").blur(function () {
            var PasswordVal = $('.password').val();
            var ConfirmPasswordVal = $('.confirmpassword').val();
            if (PasswordVal != ConfirmPasswordVal && ConfirmPasswordVal.length > 0 && PasswordVal.length > 0)
                $('reg-textbox').show();
            else
                $('reg-textbox').hide();

        });
    });

 </script>   
    
    
<!-- Content Wrapper. Contains page content -->
<div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
        <h1>
            Return
            <small><?php
                if ($_REQUEST['cid'] != '') {
                    echo 'Edit';
                } else {
                    echo 'Add New';
                }
                ?> Return</small>
        </h1>
        <ol class="breadcrumb">
            <li><a href="<?php echo $sitename; ?>"><i class="fa fa-dashboard"></i> Dashboard</a></li>
            <li><a href="#"><i class="fa fa-asterisk"></i> Master(s)</a></li>            
            <li><a href="<?php echo $sitename; ?>master/return.htm"><i class="fa fa-circle-o"></i> Return</a></li>
            <li class="active"><?php
                if ($_REQUEST['cid'] != '') {
                    echo 'Edit';
                } else {
                    echo 'Add New';
                }
                ?> Return</li>
        </ol>
    </section>

    <!-- Main content -->
    <section class="content">
        <form name="department" id="department"  method="post" enctype="multipart/form-data">
            <div class="box box-info">
                <div class="box-header with-border">
                    <h3 class="box-title"><?php
                        if ($_REQUEST['cid'] != '') {
                            echo 'Edit';
                        } else {
                            echo 'Add New';
                        }
                        ?> Return</h3>
                    <span style="float:right; font-size:13px; color: #333333; text-align: right;"><span style="color:#FF0000;">*</span> Marked Fields are Mandatory</span>
                </div>
                <div class="box-body">
                    <?php echo $msg; ?>
                    <div class="row">
                        
                        <div class="col-md-4">
                             <label>Customer ID <span style="color:#FF0000;">*</span></label>
                         <?php //$purid = get_bill_settings('prefix', '2') . str_pad(get_bill_settings('current_value', '2'), get_bill_settings('format', '1'), '0', STR_PAD_LEFT);
                                    ?>
                                    <select name="customerid" id="customerid" class="form-control" required="required">
                            <option value="">Select</option>
                            <?php
                            $customer = pFETCH("SELECT * FROM `customer` WHERE `status`=?",'1');
                            while ($customerfetch = $customer->fetch(PDO::FETCH_ASSOC)) {
                                ?>
                                <option value="<?php echo $customerfetch['id']; ?>" <?php if (getreturn('customerid', $_REQUEST['cid']) == $customerfetch['id']) { ?> selected <?php } ?>><?php echo $customerfetch['cusid']; echo '-'; echo $customerfetch['name']; ?></option>
                            <?php } ?>               
                        </select>
                                    <!-- <input type="text" name="customerid" id="customerid" class="form-control" placeholder="Enter the Customer ID" value="<?php echo getreturn("customerid",$_REQUEST['cid']); ?>" /> -->
                        </div> 
                        <div class="col-md-4">
                            <label>Object<span style="color:#FF0000;">*</span></label>
                            <select name="object" id="object" class="form-control" required="required">
                            <option value="">Select</option>
                            <?php
                            $object = pFETCH("SELECT * FROM `object` WHERE `status`=?", '1');
                            while ($objectfetch = $object->fetch(PDO::FETCH_ASSOC)) {
                                ?>
                                <option value="<?php echo $objectfetch['id']; ?>" <?php if (getreturn('object', $_REQUEST['cid']) == $objectfetch['id']) { ?> selected <?php } ?>><?php echo $objectfetch['objectname']; ?></option>
                            <?php } ?>               
                        </select> 
                        </div>
                         <div class="col-md-4">
                         <?php 
                                $receiptno = FETCH_ALL("SELECT * FROM `return` ORDER BY `id` DESC LIMIT 1");
                             ?>
                             <label>Receipt Number <span style="color:#FF0000;">*</span><?php echo $receiptno['receiptno']; ?></label>
                             
                         <?php //$purid = get_bill_settings('prefix', '2') . str_pad(get_bill_settings('current_value', '2'), get_bill_settings('format', '1'), '0', STR_PAD_LEFT);
                                    ?>
                                    <input type="text" name="receiptno" id="receiptno" placeholder="Enter the Receipt Number"  class="form-control" value="<?php echo getreturn("receiptno", $_REQUEST['cid']); ?>" />
                        </div> 
                    </div>
                    
                     <div class="clearfix"><br /></div>
                    <div class="row">
                    <div class="col-md-4">
                            <label>Date<span style="color:#FF0000;">*</span></label>
                             <div class="input-group date">
                                        <div class="input-group-addon">
                                            <i class="fa fa-calendar"></i>
                                        </div>
                                        <input type="text" class="form-control pull-right usedatepicker" name="date" id="date" required="required"  value="<?php
                                        if (isset($_REQUEST['cid']) ) {
                                            echo date('d-m-Y', strtotime(getreturn("date",$_REQUEST['cid'])));
                                        } else {
                                            echo date('d-m-Y');
                                        }
                                        ?>" >
                                    </div>  
                        </div>
                          <div class="col-md-4">
                            <label>Name <span style="color:#FF0000;">*</span></label>
                            <input type="text"  required="required" name="name" id="name" placeholder="Enter Name" class="form-control" value="<?php echo stripslashes(getreturn("name",$_REQUEST['cid'])); ?>" />
                        </div>
                        <div class="col-md-4">
                            <label>Mobile Number <span style="color:#FF0000;">*</span></label>
                            <input type="text" pattern="^\d{10}$" required="required" name="mobileno" id="mobileno" placeholder="Enter Mobile Number" class="form-control" value="<?php echo stripslashes(getreturn("mobileno",$_REQUEST['cid'])); ?>" maxlength="10"/>
                        </div>
                         <!-- <div class="col-md-4">
                            <label>ID Proof<span style="color:#FF0000;">*</span></label>
                            <input type="text" required="required" id="emailid"  name="emailid" placeholder="Enter The ID Proof" class="form-control" value="<?php echo (isset($_REQUEST['cid'])) ? stripslashes($showrecords['emailid']) : '' ?>" pattern="[a-z0-9._%+-]+@[a-z0-9.-]+\.[a-z]{2,3}$"/>
                        </div> -->
                        
                    </div>  <br>
                         <!-- <div class="panel panel-info">
                        <div class="panel-heading">ID Proof Details</div>
                        <div class="panel-body">
                            <div class="row">   
                                <div class="col-md-12">
                                    <div class="table-responsive">
                                        <table width="80%" class="table table-bordered" id="proof_table" cellpadding="0"  cellspacing="0">
                                            <thead>
                                                <tr>
                                                    <th width="5%">S.no</th>
                                                    <th width="10%">Proof Name</th>
                                                    <th width="10%">Proof</th>
                                                    <th width="5%">Delete</th>
                                                </tr>
                                            </thead>
                                            <tbody>
                                    <tr id="firstprooftr" style="display:none;">
                                        <td>1</td>
                                        <td>
                                            <input type="text" name="proofname[]" id="proofname[]" class="form-control">
                                        </td>
                                        <td><input type="file" name="proof[]" id="proof[]"  class="form-control"></td>
                                    </tr>
                                            </tbody>
                                            <tfoot>
                                                
                                                <tr><td colspan="2"></td></tr>
                                                <tr>
                                                    <td colspan="2" style="border:0;"><button type="button" class="btn btn-info" id="add_proof">Add Proof</button></td>
                                                    
                                                </tr>
                                            </tfoot>
                                        </table>

                                    </div>                                   
                                </div>
                            </div>
                        </div>

                    </div> -->
                    
<!--                     
                     <div class="clearfix"><br /></div>
                     <div class="panel panel-info">
                        <div class="panel-heading">Object Details</div>
                        <div class="panel-body">
                            <div class="row">   
                                <div class="col-md-12">
                                    <div class="table-responsive">
                                        <table width="80%" class="table table-bordered" id="task_table" cellpadding="0"  cellspacing="0">
                                            <thead>
                                                <tr>
                                                    <th width="5%">S.no</th>
                                                    <th width="10%">Object</th>
                                                    <th width="10%">Quantity</th>
                                                    <th width="5%">Delete</th>
                                                </tr>
                                            </thead>
                                            <tbody>

                                    <tr id="firsttasktr" style="display:none;">
                                                    <td>1</td>

                                                   <td>
                                                       <input type="text" name="object[]" id="object[]" class="form-control">
                                                      
                                                  </td>
                                                   
                                                    <td><input type="number" style="text-align: right;" name="quantity[]" class="form-control" /></td>
                                                  
                                                </tr>


                                            </tbody>
                                            <tfoot>
                                                
                                                <tr><td colspan="2"></td></tr>
                                                <tr>
                                                    <td colspan="2" style="border:0;"><button type="button" class="btn btn-info" id="add_task">Add Proof</button></td>
                                                    
                                                </tr>
                                            </tfoot>
                                        </table>

                                    </div>                                   
                                </div>
                            </div>
                        </div>

                    </div> -->
                     <!-- <div class="clearfix"><br /></div> -->
                    <div class="row">
                          <div class="col-md-4">
                            <label>Net Weight (in gms) <span style="color:#FF0000;"></span></label>
                            <input type="text"  required="required" name="netweight" id="netweight" placeholder="Enter Net Weight" class="form-control" value="<?php echo stripslashes(getreturn("netweight",$_REQUEST['cid'])); ?>" maxlength="10"/>
                        </div>
                        <div class="col-md-4">
                            <label>Amount <span style="color:#FF0000;"></span></label>
                            <input type="text" required="required" name="amount" id="amount" placeholder="Enter Amount" class="form-control" value="<?php echo stripslashes(getreturn("amount",$_REQUEST['cid']));  ?>" maxlength="10"/>
                        </div>
                         <div class="col-md-4">
                            <label>Interest Percent<span style="color:#FF0000;"></span></label>
                            <input type="text" id="interestpercent"  name="interestpercent" placeholder="Enter Interest Percent" class="form-control" value="<?php echo stripslashes(getreturn("interestpercent",$_REQUEST['cid'])); ?>" />
                        </div>
                       
                    </div> 
                     
                     <br>
                     <div class="row">
                          <div class="col-md-4">
                            <label>Interest <span style="color:#FF0000;"></span></label>
                            <input type="text" id="interest"  name="interest" placeholder="Enter Interest Amount" class="form-control" value="<?php echo stripslashes(getreturn("interest",$_REQUEST['cid'])); ?>" />
                            <!-- pattern="[a-z0-9._%+-]+@[a-z0-9.-]+\.[a-z]{2,3}$" -->
                        </div>
                        <div class="col-md-4">
                            <label>Status<span style="color:#FF0000;"></span></label>
                            <input type="text" id="status"  name="status" placeholder="Enter the status" class="form-control" value="<?php echo getreturn("status",$_REQUEST['cid']); ?>" />              
                         
                        </div>
                     </div>    
                </div><!-- /.box-body -->
                <div class="box-footer">
                    <div class="row">
                        <div class="col-md-6">
                            <a href="<?php echo $sitename; ?>master/return.htm">Back to Listings page</a>
                        </div>
                        <div class="col-md-6">
                            <button type="submit" name="submit" id="submit" class="btn btn-success" style="float:right;"><?php
                                if ($_REQUEST['cid'] != '') {
                                    echo 'UPDATE';
                                } else {
                                    echo 'SUBMIT';
                                }
                                ?></button>
                        </div>
                    </div>
                </div>
            </div><!-- /.box -->
        </form>
    </section><!-- /.content -->
</div><!-- /.content-wrapper -->
<?php include ('../../require/footer.php'); ?>
<script type="text/javascript">

     function show_contacts(id) {
        $.ajax({
            url: "<?php echo $sitename; ?>getpassup.php",
            data: {get_contacts_of_customer: id}
        }).done(function (data) {
            $('#choose_contacts_grid_table tbody').html(data);
        });
    }


      function delrec(elem, id) {
        if (confirm("Are you sure want to delete this Object?")) {
            $(elem).parent().remove();
            window.location.href = "<?php echo $sitename; ?>master/<?php echo $showrecords['id'] ?>/editprovider.htm?delid=" + id;
        }
    }


    $(document).ready(function (e) {
        
        $('#add_task').click(function () {

           
            var data = $('#firsttasktr').clone();
            var rem_td = $('<td />').html('<i class="fa fa-trash fa-2x" style="color:#F00;cursor:pointer;"></i>').click(function () {
                if (confirm("Do you want to delete the Offer?")) {
                    $(this).parent().remove();
                    re_assing_serial();
                   
                }
            });
            $(data).attr('id', '').show().append(rem_td);

            data = $(data);
            $('#task_table tbody').append(data);
             $('.usedatepicker').datepicker({
                autoclose: true
            });

           
            re_assing_serial();

        });
       
         $('#add_proof').click(function () {

           
            var data = $('#firstprooftr').clone();
            var rem_td = $('<td />').html('<i class="fa fa-trash fa-2x" style="color:#F00;cursor:pointer;"></i>').click(function () {
                if (confirm("Do you want to delete the Proof?")) {
                    $(this).parent().remove();
                    re_assing_serial();
                   
                }
            });
            $(data).attr('id', '').show().append(rem_td);

            data = $(data);
            $('#proof_table tbody').append(data);
             $('.usedatepicker').datepicker({
                autoclose: true
            });

           
            re_assing_serial();

        });

        

      });

    function del_addi(elem) {
        if (confirm("Are you sure want to remove this?")) {
            elem.parent().parent().remove();
            additionalprice();
        }
    }


   
   
    
    function re_assing_serial() {
        $("#task_table tbody tr").not('#firsttasktr').each(function (i, e) {
            $(this).find('td').eq(0).html(i + 1+1);
        });
        $("#proof_table tbody tr").not('#firstprooftr').each(function (i, e) {
            $(this).find('td').eq(0).html(i + 1+1);
        });
    }

</script>